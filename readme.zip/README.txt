Hotfix Magatomatique XLSX filtrable/triable

Remplacer :
- app/statsimpact/routes.py

Ce patch ne retire aucune donnée de l'export annuel par atelier.
Il ajoute :
- de vrais tableaux Excel structurés sur la feuille Synthese ;
- de vrais tableaux Excel structurés sur chaque matrice participant x sessions ;
- filtres et tris Excel natifs ;
- gel des volets : en-têtes + colonnes Nom/Prénom/Âge/Ville/Quartier restent visibles ;
- formats numériques plus propres.
